package com.example.phototextstudio

import android.content.ContentValues
import android.content.Intent
import android.graphics.*
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.view.View
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.example.phototextstudio.databinding.ActivityMainBinding
import com.googlecode.tesseract.android.TessBaseAPI
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import java.net.URL
import java.util.Locale

class MainActivity : AppCompatActivity() {
    private lateinit var binding: ActivityMainBinding
    private var originalBitmap: Bitmap? = null
    private var workingBitmap: Bitmap? = null
    private var selectedRegion: TextRegion? = null
    private var tess: TessBaseAPI? = null
    private var dataReady = false
    private val picker = registerForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) loadImage(uri)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        binding.pickButton.setOnClickListener { picker.launch("image/*") }
        binding.ocrButton.setOnClickListener { runOcr() }
        binding.applyButton.setOnClickListener { replaceSelectedText() }
        binding.clearButton.setOnClickListener {
            binding.editorView.selectedIndex = -1
            selectedRegion = null
            binding.replacementInput.setText("")
            binding.statusText.text = "انتخاب پاک شد."
        }
        binding.saveButton.setOnClickListener { saveImage() }
        binding.editorView.onRegionSelected = { index ->
            val region = binding.editorView.regions.getOrNull(index)
            selectedRegion = region
            binding.replacementInput.setText(region?.text.orEmpty())
            binding.statusText.text = if (region != null) "کادر ${index + 1} انتخاب شد." else "کادری انتخاب نشده."
        }
        binding.statusText.text = "برای OCR فارسی و انگلیسی، داده‌های زبان باید آماده باشند."
    }

    private fun loadImage(uri: Uri) {
        try {
            val bmp = contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it) }
            if (bmp == null) { toast("خواندن عکس ممکن نشد."); return }
            originalBitmap = bmp.copy(Bitmap.Config.ARGB_8888, true)
            workingBitmap = bmp.copy(Bitmap.Config.ARGB_8888, true)
            binding.editorView.bitmap = workingBitmap
            binding.editorView.regions = emptyList()
            binding.editorView.selectedIndex = -1
            selectedRegion = null
            binding.statusText.text = "عکس آماده است. برای شناسایی نوشته‌ها «تشخیص متن» را بزنید."
        } catch (e: Exception) { toast("خطا در بازکردن عکس: ${e.message}") }
    }

    private fun runOcr() {
        val bmp = workingBitmap ?: run { toast("ابتدا عکس انتخاب کنید."); return }
        binding.ocrButton.isEnabled = false
        binding.statusText.text = "در حال آماده‌سازی موتور تشخیص متن…"
        lifecycleScope.launch {
            try {
                val result = withContext(Dispatchers.IO) {
                    ensureTessData()
                    val api = TessBaseAPI()
                    val dir = File(filesDir, "tesseract")
                    if (!api.init(dir.absolutePath, "fas+eng")) {
                        api.end()
                        throw IllegalStateException("موتور OCR شروع نشد؛ داده‌های fas و eng را بررسی کنید.")
                    }
                    try {
                        api.pageSegMode = TessBaseAPI.PageSegMode.PSM_AUTO
                        api.setImage(bmp)
                        val text = api.utF8Text ?: ""
                        val iterator = api.resultIterator
                        val found = mutableListOf<TextRegion>()
                        if (iterator != null) {
                            do {
                                val word = iterator.getUTF8Text(TessBaseAPI.PageIteratorLevel.RIL_WORD)
                                val rect = Rect()
                                if (!word.isNullOrBlank() && iterator.getBoundingRect(TessBaseAPI.PageIteratorLevel.RIL_WORD, rect)) {
                                    found.add(TextRegion(word.trim(), Rect(rect), iterator.confidence(TessBaseAPI.PageIteratorLevel.RIL_WORD)))
                                }
                            } while (iterator.next(TessBaseAPI.PageIteratorLevel.RIL_WORD))
                        }
                        Pair(found, text)
                    } finally {
                        api.end()
                    }
                }
                val (found, fullText) = result
                binding.editorView.regions = found
                binding.editorView.selectedIndex = -1
                selectedRegion = null
                binding.statusText.text = if (found.isEmpty()) {
                    "متنی پیدا نشد. وضوح عکس را بررسی کنید."
                } else "تعداد ${found.size} محدودهٔ کلمه پیدا شد؛ روی کلمه بزنید."
                if (found.isNotEmpty()) {
                    val sample = fullText.trim().take(160)
                    Toast.makeText(this@MainActivity, "نمونه متن: $sample", Toast.LENGTH_LONG).show()
                }
            } catch (e: Exception) {
                binding.statusText.text = "OCR ناموفق بود: ${e.message ?: "خطای نامشخص"}"
                toast("اگر دانلود زبان شکست خورده، اینترنت را روشن و دوباره امتحان کنید.")
            } finally {
                binding.ocrButton.isEnabled = true
            }
        }
    }

    private fun ensureTessData() {
        val dataDir = File(filesDir, "tesseract/tessdata")
        if (!dataDir.exists()) dataDir.mkdirs()
        val languages = listOf(
            "eng" to "https://raw.githubusercontent.com/tesseract-ocr/tessdata_fast/main/eng.traineddata",
            "fas" to "https://raw.githubusercontent.com/tesseract-ocr/tessdata_fast/main/fas.traineddata"
        )
        for ((lang, url) in languages) {
            val target = File(dataDir, "$lang.traineddata")
            if (!target.exists() || target.length() < 100_000L) {
                URL(url).openConnection().apply {
                    connectTimeout = 20000
                    readTimeout = 60000
                }.getInputStream().use { input ->
                    FileOutputStream(target).use { output -> input.copyTo(output) }
                }
            }
        }
    }

    private fun replaceSelectedText() {
        val bitmap = workingBitmap ?: run { toast("ابتدا عکس انتخاب کنید."); return }
        val region = selectedRegion ?: run { toast("ابتدا یک محدوده را انتخاب کنید."); return }
        val newText = binding.replacementInput.text.toString()
        if (newText.isBlank()) { toast("متن جدید را وارد کنید."); return }
        val rect = region.bounds
        val canvas = Canvas(bitmap)
        val patch = sampleBackground(bitmap, rect)
        val textColor = estimateTextColor(bitmap, rect, patch)
        val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = patch; style = Paint.Style.FILL }
        val pad = maxOf(3, rect.height() / 10)
        canvas.drawRoundRect(RectF((rect.left-pad).toFloat(), (rect.top-pad).toFloat(),
            (rect.right+pad).toFloat(), (rect.bottom+pad).toFloat()), 2f, 2f, fill)
        val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = textColor
            textSize = (rect.height() * 0.85f).coerceAtLeast(16f)
            typeface = Typeface.create("sans-serif", Typeface.NORMAL)
        }
        val baseline = rect.bottom.toFloat() - rect.height() * 0.12f
        canvas.drawText(newText, rect.left.toFloat(), baseline, textPaint)
        binding.editorView.bitmap = bitmap
        binding.editorView.regions = binding.editorView.regions.filterNot { it == region }
        binding.editorView.selectedIndex = -1
        selectedRegion = null
        binding.replacementInput.setText("")
        binding.statusText.text = "متن جدید اعمال شد. نتیجه را بررسی کنید؛ ترمیم خودکار روی پس‌زمینه‌های پیچیده دقیق نیست."
    }

    private fun sampleBackground(bmp: Bitmap, r: Rect): Int {
        val points = listOf(
            r.left.coerceAtLeast(0) to (r.top - 4).coerceAtLeast(0),
            r.right.coerceAtMost(bmp.width - 1) to (r.top - 4).coerceAtLeast(0),
            r.left.coerceAtLeast(0) to (r.bottom + 4).coerceAtMost(bmp.height - 1),
            r.right.coerceAtMost(bmp.width - 1) to (r.bottom + 4).coerceAtMost(bmp.height - 1)
        )
        val colors = points.map { (x, y) -> bmp.getPixel(x, y) }
        val a = colors.map { Color.alpha(it) }.average().toInt()
        val red = colors.map { Color.red(it) }.average().toInt()
        val green = colors.map { Color.green(it) }.average().toInt()
        val blue = colors.map { Color.blue(it) }.average().toInt()
        return Color.argb(a, red, green, blue)
    }

    private fun estimateTextColor(bmp: Bitmap, r: Rect, background: Int): Int {
        var dark = 0; var light = 0
        val stepX = maxOf(1, r.width() / 30); val stepY = maxOf(1, r.height() / 12)
        var count = 0
        var y = r.top.coerceAtLeast(0)
        while (y < r.bottom.coerceAtMost(bmp.height)) {
            var x = r.left.coerceAtLeast(0)
            while (x < r.right.coerceAtMost(bmp.width)) {
                val c = bmp.getPixel(x, y)
                val lum = (Color.red(c)*0.299 + Color.green(c)*0.587 + Color.blue(c)*0.114)
                val bgLum = (Color.red(background)*0.299 + Color.green(background)*0.587 + Color.blue(background)*0.114)
                if (kotlin.math.abs(lum-bgLum) > 45) { if (lum < 128) dark++ else light++ }
                count++; x += stepX
            }
            y += stepY
        }
        return if (dark >= light) Color.BLACK else Color.WHITE
    }

    private fun saveImage() {
        val bmp = workingBitmap ?: run { toast("عکسی برای ذخیره وجود ندارد."); return }
        try {
            val values = ContentValues().apply {
                put(MediaStore.Images.Media.DISPLAY_NAME, "PhotoTextStudio_${System.currentTimeMillis()}.png")
                put(MediaStore.Images.Media.MIME_TYPE, "image/png")
                put(MediaStore.Images.Media.RELATIVE_PATH, Environment.DIRECTORY_PICTURES + "/PhotoTextStudio")
            }
            val uri = contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values)
                ?: throw IllegalStateException("ساخت فایل خروجی ممکن نشد.")
            contentResolver.openOutputStream(uri)?.use { out ->
                if (!bmp.compress(Bitmap.CompressFormat.PNG, 100, out)) throw IllegalStateException("ذخیره عکس شکست خورد.")
            }
            binding.statusText.text = "عکس در گالری، پوشهٔ Pictures/PhotoTextStudio ذخیره شد."
            toast("ذخیره شد.")
        } catch (e: Exception) { toast("خطا در ذخیره: ${e.message}") }
    }

    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_LONG).show()
}
