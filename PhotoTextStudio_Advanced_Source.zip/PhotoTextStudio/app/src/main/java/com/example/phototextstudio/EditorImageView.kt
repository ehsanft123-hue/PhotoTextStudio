package com.example.phototextstudio

import android.content.Context
import android.graphics.*
import android.util.AttributeSet
import android.view.MotionEvent
import android.view.View
import kotlin.math.min

data class TextRegion(val text: String, val bounds: Rect, val confidence: Float = 0f)

class EditorImageView @JvmOverloads constructor(
    context: Context, attrs: AttributeSet? = null
) : View(context, attrs) {
    var bitmap: Bitmap? = null
        set(value) { field = value; invalidate() }
    var regions: List<TextRegion> = emptyList()
        set(value) { field = value; invalidate() }
    var selectedIndex: Int = -1
        set(value) { field = value; invalidate() }
    var onRegionSelected: ((Int) -> Unit)? = null
    private val imagePaint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
    private val borderPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; strokeWidth = 3f; color = Color.rgb(108, 99, 255)
    }
    private val selectedPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; strokeWidth = 5f; color = Color.rgb(40, 201, 168)
    }
    private val labelPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE; textSize = 28f; typeface = Typeface.DEFAULT_BOLD
    }
    private var dest = RectF()
    private fun updateDest() {
        val b = bitmap ?: return
        val scale = min(width.toFloat() / b.width, height.toFloat() / b.height)
        val w = b.width * scale; val h = b.height * scale
        dest = RectF((width-w)/2f, (height-h)/2f, (width+w)/2f, (height+h)/2f)
    }
    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val b = bitmap
        if (b == null) {
            val p = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.LTGRAY; textSize = 34f; textAlign = Paint.Align.CENTER }
            canvas.drawText("عکس را انتخاب کنید", width/2f, height/2f, p)
            return
        }
        updateDest()
        canvas.drawBitmap(b, null, dest, imagePaint)
        regions.forEachIndexed { index, region ->
            val r = toViewRect(region.bounds)
            canvas.drawRoundRect(r, 8f, 8f, if (index == selectedIndex) selectedPaint else borderPaint)
            if (index == selectedIndex) {
                val label = (index + 1).toString()
                canvas.drawText(label, r.left + 5f, (r.top - 8f).coerceAtLeast(28f), labelPaint)
            }
        }
    }
    private fun toViewRect(r: Rect): RectF {
        val b = bitmap ?: return RectF()
        return RectF(
            dest.left + r.left * dest.width() / b.width,
            dest.top + r.top * dest.height() / b.height,
            dest.left + r.right * dest.width() / b.width,
            dest.top + r.bottom * dest.height() / b.height
        )
    }
    override fun onTouchEvent(event: MotionEvent): Boolean {
        if (event.action == MotionEvent.ACTION_UP && bitmap != null) {
            updateDest()
            val x = (event.x - dest.left) * bitmap!!.width / dest.width()
            val y = (event.y - dest.top) * bitmap!!.height / dest.height()
            val found = regions.indexOfLast { it.bounds.contains(x.toInt(), y.toInt()) }
            if (found >= 0) { selectedIndex = found; onRegionSelected?.invoke(found); invalidate() }
            performClick()
            return true
        }
        return true
    }
    override fun performClick(): Boolean { super.performClick(); return true }
}
