package com.example.phototextstudio

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.example.phototextstudio.databinding.ActivityTermsBinding

class TermsActivity : AppCompatActivity() {
    private lateinit var binding: ActivityTermsBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val prefs = getSharedPreferences("settings", MODE_PRIVATE)
        if (prefs.getBoolean("accepted_terms", false)) {
            startActivity(Intent(this, MainActivity::class.java))
            finish()
            return
        }
        binding = ActivityTermsBinding.inflate(layoutInflater)
        setContentView(binding.root)
        binding.acceptCheck.setOnCheckedChangeListener { _, checked ->
            binding.continueButton.isEnabled = checked
        }
        binding.continueButton.setOnClickListener {
            prefs.edit().putBoolean("accepted_terms", true).apply()
            startActivity(Intent(this, MainActivity::class.java))
            finish()
        }
    }
}
